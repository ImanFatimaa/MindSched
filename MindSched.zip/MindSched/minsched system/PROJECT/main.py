# importing necessary libraries and modules
from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from flask_login import login_user, logout_user, login_manager, LoginManager
from flask_login import login_required, current_user
import json

# setting up the Flask application
local_server = True
app = Flask(__name__)
app.secret_key = 'hmsprojects'  # secret key for session management

# setting up the login manager for user authentication
login_manager = LoginManager(app)
login_manager.login_view = 'login'  # defining the login view route


# function to load the current user from the database
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# setting up the database uri for mysql
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/mind'
db = SQLAlchemy(app)  # setting up sqlalchemy

# defining the table model for the "test" table
class Test(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))

# defining the table model for the "user" table (for user credentials)
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50))
    usertype = db.Column(db.String(50))
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(1000))

# defining the table model for the "patients" table
class Patients(db.Model):
    pid = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(50))
    name = db.Column(db.String(50))
    gender = db.Column(db.String(50))
    slot = db.Column(db.String(50))
    disease = db.Column(db.String(50))
    time = db.Column(db.String(50), nullable=False)
    date = db.Column(db.String(50), nullable=False)
    dept = db.Column(db.String(50))
    number = db.Column(db.String(50))

# defining the table model for the "doctors" table
class Doctors(db.Model):
    did = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(50))
    doctorname = db.Column(db.String(50))
    dept = db.Column(db.String(50))

# defining the table model for the "trigr" table (for tracking actions)
class Trigr(db.Model):
    tid = db.Column(db.Integer, primary_key=True)
    pid = db.Column(db.Integer)
    email = db.Column(db.String(50))
    name = db.Column(db.String(50))
    action = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))

# home page route
@app.route('/')
def index():
    return render_template('index.html')

# doctors page route, handles post and get requests
@app.route('/doctors', methods=['POST', 'GET'])
def doctors():
    if request.method == "POST":
        # getting data from the form
        email = request.form.get('email')
        doctorname = request.form.get('doctorname')
        dept = request.form.get('dept')

        # adding new doctor data to the database
        query = Doctors(email=email, doctorname=doctorname, dept=dept)
        db.session.add(query)
        db.session.commit()
        flash("information is stored", "primary")  # flashing success message

    return render_template('doctor.html')

# patients page route, handles post and get requests, requires login
@app.route('/patients', methods=['POST', 'GET'])
@login_required
def patient():
    # fetching the list of doctors from the database
    doct = Doctors.query.all()

    if request.method == "POST":
        # getting data from the form
        email = request.form.get('email')
        name = request.form.get('name')
        gender = request.form.get('gender')
        slot = request.form.get('slot')
        disease = request.form.get('disease')
        time = request.form.get('time')
        date = request.form.get('date')
        dept = request.form.get('dept')
        number = request.form.get('number')

        # validating the phone number length
        if len(number) < 10 or len(number) > 10:
            flash("please give 10 digit number")
            return render_template('patient.html', doct=doct)

        # adding new patient data to the database
        query = Patients(email=email, name=name, gender=gender, slot=slot, disease=disease, time=time, date=date, dept=dept, number=number)
        db.session.add(query)
        db.session.commit()

        flash("booking confirmed", "info")  # flashing success message

    return render_template('patient.html', doct=doct)

# bookings page route, shows the patient's bookings or all bookings if user is a doctor
@app.route('/bookings')
@login_required
def bookings():
    em = current_user.email
    if current_user.usertype == "Doctor":
        # fetching all patients if user is a doctor
        query = Patients.query.all()
        return render_template('booking.html', query=query)
    else:
        # fetching patient's specific bookings if user is a patient
        query = Patients.query.filter_by(email=em)
        return render_template('booking.html', query=query)

# edit page route, allows editing of booking details
@app.route("/edit/<string:pid>", methods=['POST', 'GET'])
@login_required
def edit(pid):
    if request.method == "POST":
        # getting updated data from the form
        email = request.form.get('email')
        name = request.form.get('name')
        gender = request.form.get('gender')
        slot = request.form.get('slot')
        disease = request.form.get('disease')
        time = request.form.get('time')
        date = request.form.get('date')
        dept = request.form.get('dept')
        number = request.form.get('number')

        # updating the patient details in the database
        post = Patients.query.filter_by(pid=pid).first()
        post.email = email
        post.name = name
        post.gender = gender
        post.slot = slot
        post.disease = disease
        post.time = time
        post.date = date
        post.dept = dept
        post.number = number
        db.session.commit()

        flash("slot is updated", "success")
        return redirect('/bookings')  # redirecting to bookings page

    posts = Patients.query.filter_by(pid=pid).first()
    return render_template('edit.html', posts=posts)

# delete page route, allows deleting a booking
@app.route("/delete/<string:pid>", methods=['POST', 'GET'])
@login_required
def delete(pid):
    # deleting the patient booking from the database
    query = Patients.query.filter_by(pid=pid).first()
    db.session.delete(query)
    db.session.commit()
    flash("slot deleted successfully", "danger")
    return redirect('/bookings')  # redirecting to bookings page

# signup page route, handles user registration
@app.route('/signup', methods=['POST', 'GET'])
def signup():
    if request.method == "POST":
        # getting signup details from the form
        username = request.form.get('username')
        usertype = request.form.get('usertype')
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()

        if user:
            flash("email already exists", "warning")  # flashing error message if email already exists
            return render_template('/signup.html')

        # adding new user data to the database
        myquery = User(username=username, usertype=usertype, email=email, password=password)
        db.session.add(myquery)
        db.session.commit()
        flash("signup success. please login", "success")  # flashing success message
        return render_template('login.html')

    return render_template('signup.html')

# login page route, handles user login
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == "POST":
        # getting login details from the form
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()

        if user and user.password == password:
            login_user(user)  # logging the user in
            flash("login success", "primary")  # flashing success message
            return redirect(url_for('index'))  # redirecting to the home page
        else:
            flash("invalid credentials", "danger")  # flashing error message for invalid credentials
            return render_template('login.html')

    return render_template('login.html')

# logout page route, handles user logout
@app.route('/logout')
@login_required
def logout():
    logout_user()  # logging the user out
    flash("logout successful", "warning")  # flashing success message
    return redirect(url_for('login'))  # redirecting to the login page

# test route, checks database connection
@app.route('/test')
def test():
    try:
        Test.query.all()  # testing database connection
        return 'my database is connected'
    except:
        return 'my db is not connected'  # error message if database connection fails

# details page route, shows all trigger logs
@app.route('/details')
@login_required
def details():
    posts = Trigr.query.all()  # fetching all trigger logs
    return render_template('trigers.html', posts=posts)

# search page route, handles doctor search functionality
@app.route('/search', methods=['POST', 'GET'])
@login_required
def search():
    if request.method == "POST":
        # getting search query from the form
        query = request.form.get('search')
        dept = Doctors.query.filter_by(dept=query).first()
        name = Doctors.query.filter_by(doctorname=query).first()
        if name:
            flash("doctor is available", "info")  # flashing success message if doctor is found
        else:
            flash("doctor is not available", "danger")  # flashing error message if doctor is not found
    return render_template('index.html')

# running the app in debug mode
app.run(debug=True)
