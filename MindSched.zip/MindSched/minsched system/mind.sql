--set sql mode to avoid auto-increment issues
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";  --ensures that inserting values of zero does not affect auto-incrementing fields

--start a transaction to ensure atomicity of operations
START TRANSACTION;  --begins a new transaction to ensure that all operations are completed successfully before committing

--set the timezone for the database session
SET time_zone = "+00:00";  --sets the session timezone to UTC for consistent timestamp handling
--created the doctors table with columns for id, email, doctor name, and department
create table doctors (
  did int(11) not null,
  email varchar(50) not null,
  doctorname varchar(50) not null,
  dept varchar(100) not null
) engine=innoDB default charset=utf8mb4;

--inserted some sample data into the doctors table for testing
insert into doctors (did, email, doctorname, dept) values
(1, 'iman@gmail.com', 'Iman', 'General Psychiatrist'),
(2, 'iqra@gmail.com', 'Amrutha Bhatta', 'Forensic Psychiatrist'),
(3, 'aleena@gmail.com', 'Aadithyaa', 'Child Psychiatrist'),
(4, 'abeesha@gmail.com', 'Abeesha', 'Neuropsychiatry'),
(5, 'fatima@gmail.com', 'Fatima', 'Addiction Psychiatrist');

--created the patients table with relevant columns like patient id, name, disease, etc.
create table patients (
  pid int(11) not null,
  email varchar(50) not null,
  name varchar(50) not null,
  gender varchar(50) not null,
  slot varchar(50) not null,
  disease varchar(50) not null,
  time time not null,
  date date not null,
  dept varchar(50) not null,
  number varchar(12) not null
) engine=innoDB default charset=utf8mb4;

--inserted some sample data into the patients table for testing
insert into patients (pid, email, name, gender, slot, disease, time, date, dept, number) values
(2, 'iman@gmail.com', 'Iman', 'Female', 'evening', 'psychiatric', '21:20:00', '2020-02-02', 'General Psychiatrist', '9874561110'),
(5, 'iqra@gmail.com', 'Iqra', 'Female', 'morning', 'psychiatric', '18:06:00', '2020-11-18', 'General Psychiatrist', '9874563210'),
(7, 'aleena@gmail.com', 'Aleena', 'Female', 'evening', 'psychiatric', '22:18:00', '2020-11-05', 'Child Psychiatrist', '9874563210'),
(8, 'aleena2@gmail.com', 'Aleena', 'Female', 'evening', 'psychiatric', '22:18:00', '2020-11-05', 'Forensic Psychiatrist', '9874563210'),
(9, 'iman23@gmail.com', 'Iman', 'Female', 'morning', 'psychiatric', '17:27:00', '2020-11-26', 'Psychiatrist', '9874563210'),
(10, 'iqra89@gmail.com', 'Iqra', 'Female', 'evening', 'psychiatric', '16:25:00', '2020-12-09', 'Addiction Psychiatrist', '9874589654'),
(15, 'xyz1@gmail.com', 'Xyz', 'Female', 'morning', 'psychiatric', '20:42:00', '2021-01-23', 'Addiction Psychiatrist', '9874563210'),
(16, 'xyz2@gmail.com', 'Xyz', 'Female', 'evening', 'psychiatric', '15:46:00', '2021-01-31', 'General Psychiatrist', '9874587496'),
(17, 'xyz3@gmail.com', 'Xyz', 'Female', 'evening', 'psychiatric', '15:48:00', '2021-01-23', 'General Psychiatrist', '9874563210');

--created a simple test table for some initial testing
create table test (
  id int(11) not null,
  name varchar(20) not null,
  email varchar(20) not null
) engine=innoDB default charset=utf8mb4;

--inserted some sample data into the test table for checking functionality
insert into test (id, name, email) values
(1, 'Iman', 'iman@GMAIL.COM'),
(2, 'Test', 'test@gmail.com');

--created a 'trigr' table to track trigger actions for patients
create table trigr (
  tid int(11) not null,
  pid int(11) not null,
  email varchar(50) not null,
  name varchar(50) not null,
  action varchar(50) not null,
  timestamp datetime not null
) engine=innoDB default charset=utf8mb4;

--inserted sample data into the trigr table to log actions like insert, update, and delete
insert into trigr (tid, pid, email, name, action, timestamp) values
(1, 12, 'iman@gmail.com', 'Iman', 'PATIENT INSERTED', '2020-12-02 16:35:10'),
(2, 11, 'iqra@gmail.com', 'Iqra', 'PATIENT INSERTED', '2020-12-02 16:37:34'),
(3, 10, 'iqra@gmail.com', 'Iqra', 'PATIENT UPDATED', '2020-12-02 16:38:27'),
(4, 11, 'iqra@gmail.com', 'Iqra', 'PATIENT UPDATED', '2020-12-02 16:38:33'),
(5, 12, 'iman@gmail.com', 'Iman', 'PATIENT DELETED', '2020-12-02 16:40:40'),
(6, 11, 'iqra@gmail.com', 'Iqra', 'PATIENT DELETED', '2020-12-02 16:41:10'),
(7, 13, 'aleena@gmail.com', 'Aleena', 'PATIENT INSERTED', '2020-12-02 16:50:21');

--created a user table to manage user credentials (for doctors, patients, etc.)
create table user (
  id int(11) not null,
  username varchar(50) not null,
  usertype varchar(50) not null,
  email varchar(50) not null,
  password varchar(1000) not null
) engine=innoDB default charset=utf8mb4;

--inserted sample user data for testing user logins and roles
insert into user (id, username, usertype, email, password) values
(13, 'Iman', 'Doctor', 'iman@gmail.com', 'iman'),
(14, 'Iqra', 'Patient', 'iqra@gmail.com', 'iqra'),
(15, 'Aleena', 'Patient', 'aleena@gmail.com', 'aleena');

--added primary keys to the tables for unique identification of rows
alter table doctors
  add primary key (did);

alter table patients
  add primary key (pid);

alter table test
  add primary key (id);

alter table trigr
  add primary key (tid);

alter table user
  add primary key (id),
  add unique key email (email);

--modified columns to auto-increment so that ids are generated automatically when inserting new rows
alter table doctors
  modify did int(11) not null auto_increment, auto_increment=6;

alter table patients
  modify pid int(11) not null auto_increment, auto_increment=18;

alter table test
  modify id int(11) not null auto_increment, auto_increment=12;

alter table trigr
  modify tid int(11) not null auto_increment, auto_increment=20;

alter table user
  modify id int(11) not null auto_increment, auto_increment=16;

--committed the transaction to save all changes permanently
commit;
